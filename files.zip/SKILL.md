# HeatCheck HQ — Graphic Builder Skill

## Purpose
Generate viral sports stats graphics for Twitter/X (1200×675px) from HeatCheck HQ dashboard data. This skill enables Claude to create, customize, and export branded stat graphics for MLB, NBA, and NFL content.

## When to Use
- User asks to "make a graphic" or "create a tweet graphic" for sports stats
- User provides data from HeatCheck HQ dashboards (NRFI, Hot Hitters, Pitching Stats, First Basket, etc.)
- User wants to generate social media content for sports betting analytics
- User mentions any of the 13 HeatCheck dashboards

## Brand Guidelines
- **Brand Name:** HeatCheck HQ
- **Handle:** @heatcheckhq
- **Website:** heatcheckhq.io
- **Footer CTA:** "FREE DASHBOARDS → HEATCHECKHQ.IO"
- **Font:** Oswald (Google Fonts) for display, system sans-serif for UI

## Supported Dashboards (13 Total)

### MLB (7)
| Dashboard | Key Columns | Default Theme | Callout |
|-----------|------------|---------------|---------|
| NRFI | Pitcher, Record, NRFI %, Streak, Opp NRFI % | fire | 🔒 LOCK OF THE DAY |
| Hot Hitters | Player, Team, Streak, AVG (L10), XBH (L10) | fire | 🔥 HOT STREAK ALERT |
| Hitter vs Pitcher | Batter, VS Pitcher, AB, AVG, OPS, HR | neon | ⚡ TODAY'S MATCHUP EDGE |
| Pitching Stats | Pitcher, Hand, K/GM, K%, CSW%, IP | ice | 📊 BY THE NUMBERS |
| Weather | Matchup, Temp, Wind, Direction, Impact | ice | 🌤 WEATHER WATCH |
| Due for HR | Player, Barrel%, Exit Velo, xSLG, SLG, Gap | gold | 💣 OVERDUE MASHERS |
| Streak Tracker | Player, Stat, Threshold, Streak, Hit Rate | fire | 🔥 ACTIVE STREAKS |

### NBA (4)
| Dashboard | Key Columns | Default Theme | Callout |
|-----------|------------|---------------|---------|
| First Basket | Player, Tip Win%, 1st Shot%, FG Rank, Odds Value | neon | 🏀 TIP-OFF EDGE |
| Head-to-Head | Stat, Team A, Team B, Edge | fire | ⚔️ WHO'S GOT THE EDGE? |
| Def vs Position | Position, VS Team, PTS Allowed, REB, AST, Rank | emerald | 💰 BEST VALUE PLAYS |
| Streak Tracker | Player, Stat, Line, Streak, Hit Rate | neon | 🔥 ACTIVE STREAKS |

### NFL (2)
| Dashboard | Key Columns | Default Theme | Callout |
|-----------|------------|---------------|---------|
| Matchup | Stat, Team A, Rank, Team B, Rank | emerald | 🏈 GAME DAY EDGE |
| Def vs Position | Position, VS Team, FPTS Allowed, YDS, TD, Rank | fire | 💰 EXPLOIT THE MATCHUP |

## Themes
| Theme ID | Name | Best For |
|----------|------|----------|
| fire | 🔥 HeatCheck Fire (red) | Hot streaks, NRFI locks, alerts |
| ice | ❄️ Ice Cold (blue) | Pitching stats, cold fades, weather |
| neon | ⚡ Neon Purple | First basket, matchups, NBA |
| emerald | 💰 Money Green | Value plays, DFS, defense vs position |
| gold | 🏆 Champion Gold | Due for HR, top performers |

## Graphic Features
- **Hero Row:** One highlighted row with glow effect for the #1 pick (set `isHero: true`)
- **Rank Badges:** 👑🥈🥉 for top 3 rows, numbers for rest
- **Row Badges:** 🔒 Lock, 🔥 Hot, 🚨 Alert, ⭐ Pick, 💰 Value, 🥶 Cold, 💣 Bomb
- **Callout Bar:** Glowing banner between header and table for hook text
- **Conditional Coloring:** Green/red cell backgrounds based on stat values
- **Streak Arrows:** Cells starting with `+` get green ▲, `-` get red ▼

## Tweet Caption Template Variables
- `{hero}` — Auto-fills with hero row player name and stats
- `{count}` — Auto-fills with total number of rows

## Example Caption Template
```
🔒 Today's NRFI locks are IN

{hero}

📊 Full breakdown on all {count} matchups

🔥 Free dashboards → heatcheckhq.io

#MLB #NRFI #SportsBetting #BaseballBets
```

## Data Input Format
Data can be pasted as tab-separated or multi-space-separated text:
```
Pitcher	Starts	NRFI %	Streak
David Peterson	15-2	88%	+8
Cal Quantrill	14-3	82%	+5
```

## Web App Location
The graphic builder is deployed as a Next.js app. Source code is in:
- `app/builder.js` — Main client component with all logic
- `app/page.js` — Page wrapper
- `app/layout.js` — HTML layout with Oswald font

Dependencies: `next`, `react`, `react-dom`, `html-to-image`

## Output Specs
- **Dimensions:** 1200×675px (Twitter/X optimal)
- **Export:** PNG at 2× resolution (2400×1350) via `html-to-image`
- **File naming:** `heatcheck-{dashboard}-{timestamp}.png`

## Workflow for Daily Content
1. Open HeatCheck dashboard (e.g., heatcheckhq.io/mlb/nrfi)
2. Select relevant data rows
3. Paste into graphic builder
4. Set hero row + badges on top picks
5. Download PNG + copy auto-generated tweet
6. Post to Twitter/X

## Tips for Viral Graphics
- Always set ONE hero row — it creates a focal point
- Use 🔒 Lock badge sparingly (1-2 per graphic) for authority
- Keep rows to 5-7 for quick scanability
- Callout bar is the hook — make it provocative
- Include hashtags for discoverability
- Post during game day for maximum engagement
